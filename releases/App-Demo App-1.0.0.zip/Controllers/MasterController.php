<?php

namespace WebApps\Apps\DemoApp\Controllers;

use App\Http\Controllers\AppsController;

class MasterController extends AppsController
{
    //
}
